--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.3
-- Dumped by pg_dump version 9.6.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE viper;
--
-- Name: viper; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE viper WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United States.1252' LC_CTYPE = 'English_United States.1252';


ALTER DATABASE viper OWNER TO postgres;

\connect viper

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: investing; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA investing;


ALTER SCHEMA investing OWNER TO postgres;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = investing, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: stock_exchanges; Type: TABLE; Schema: investing; Owner: postgres
--

CREATE TABLE stock_exchanges (
    id smallint NOT NULL,
    name character varying(20) NOT NULL
);


ALTER TABLE stock_exchanges OWNER TO postgres;

--
-- Name: stock_prices; Type: TABLE; Schema: investing; Owner: postgres
--

CREATE TABLE stock_prices (
    id integer NOT NULL,
    symbol character varying NOT NULL,
    date date NOT NULL,
    open numeric(7,2) NOT NULL,
    high numeric(7,2) NOT NULL,
    low numeric(7,2) NOT NULL,
    close numeric(7,2) NOT NULL,
    volume integer NOT NULL,
    adj_open numeric(7,2),
    adj_high numeric(7,2),
    adj_low numeric(7,2),
    adj_close numeric(7,2),
    adj_volume integer,
    dividend_cash numeric(7,2),
    split_factor numeric(7,2)
);


ALTER TABLE stock_prices OWNER TO postgres;

--
-- Name: stock_price_id_seq; Type: SEQUENCE; Schema: investing; Owner: postgres
--

CREATE SEQUENCE stock_price_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE stock_price_id_seq OWNER TO postgres;

--
-- Name: stock_price_id_seq; Type: SEQUENCE OWNED BY; Schema: investing; Owner: postgres
--

ALTER SEQUENCE stock_price_id_seq OWNED BY stock_prices.id;


--
-- Name: stock_prices_historical; Type: TABLE; Schema: investing; Owner: postgres
--

CREATE TABLE stock_prices_historical (
    id bigint NOT NULL,
    symbol character varying NOT NULL,
    date date NOT NULL,
    open numeric(7,2) NOT NULL,
    high numeric(7,2) NOT NULL,
    low numeric(7,2) NOT NULL,
    close numeric(7,2) NOT NULL,
    volume integer NOT NULL,
    adj_open numeric(7,2),
    adj_high numeric(7,2),
    adj_low numeric(7,2),
    adj_close numeric(7,2),
    adj_volume integer,
    dividend_cash numeric(7,2),
    split_factor numeric(7,2)
);


ALTER TABLE stock_prices_historical OWNER TO postgres;

--
-- Name: stock_prices_historical_id_seq; Type: SEQUENCE; Schema: investing; Owner: postgres
--

CREATE SEQUENCE stock_prices_historical_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE stock_prices_historical_id_seq OWNER TO postgres;

--
-- Name: stock_prices_historical_id_seq; Type: SEQUENCE OWNED BY; Schema: investing; Owner: postgres
--

ALTER SEQUENCE stock_prices_historical_id_seq OWNED BY stock_prices_historical.id;


--
-- Name: tickers; Type: TABLE; Schema: investing; Owner: postgres
--

CREATE TABLE tickers (
    id integer NOT NULL,
    name text NOT NULL,
    sector text NOT NULL,
    industry text,
    created_date timestamp with time zone NOT NULL,
    stock_exchange smallint NOT NULL,
    symbol character varying(20) NOT NULL,
    is_tradable boolean NOT NULL,
    trading_end_date date
);


ALTER TABLE tickers OWNER TO postgres;

--
-- Name: tickers_id_seq; Type: SEQUENCE; Schema: investing; Owner: postgres
--

CREATE SEQUENCE tickers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tickers_id_seq OWNER TO postgres;

--
-- Name: tickers_id_seq; Type: SEQUENCE OWNED BY; Schema: investing; Owner: postgres
--

ALTER SEQUENCE tickers_id_seq OWNED BY tickers.id;


--
-- Name: stock_prices id; Type: DEFAULT; Schema: investing; Owner: postgres
--

ALTER TABLE ONLY stock_prices ALTER COLUMN id SET DEFAULT nextval('stock_price_id_seq'::regclass);


--
-- Name: stock_prices_historical id; Type: DEFAULT; Schema: investing; Owner: postgres
--

ALTER TABLE ONLY stock_prices_historical ALTER COLUMN id SET DEFAULT nextval('stock_prices_historical_id_seq'::regclass);


--
-- Name: tickers id; Type: DEFAULT; Schema: investing; Owner: postgres
--

ALTER TABLE ONLY tickers ALTER COLUMN id SET DEFAULT nextval('tickers_id_seq'::regclass);


--
-- Name: stock_exchanges StockExchanges_pkey; Type: CONSTRAINT; Schema: investing; Owner: postgres
--

ALTER TABLE ONLY stock_exchanges
    ADD CONSTRAINT "StockExchanges_pkey" PRIMARY KEY (id);


--
-- Name: stock_prices stock_price_pkey; Type: CONSTRAINT; Schema: investing; Owner: postgres
--

ALTER TABLE ONLY stock_prices
    ADD CONSTRAINT stock_price_pkey PRIMARY KEY (id);


--
-- Name: stock_prices_historical stock_prices_historical_pkey; Type: CONSTRAINT; Schema: investing; Owner: postgres
--

ALTER TABLE ONLY stock_prices_historical
    ADD CONSTRAINT stock_prices_historical_pkey PRIMARY KEY (id);


--
-- Name: stock_prices_historical stock_prices_historical_unique_symbol_and_date; Type: CONSTRAINT; Schema: investing; Owner: postgres
--

ALTER TABLE ONLY stock_prices_historical
    ADD CONSTRAINT stock_prices_historical_unique_symbol_and_date UNIQUE (symbol, date);


--
-- Name: stock_prices stock_prices_symbol_unique; Type: CONSTRAINT; Schema: investing; Owner: postgres
--

ALTER TABLE ONLY stock_prices
    ADD CONSTRAINT stock_prices_symbol_unique UNIQUE (symbol);


--
-- Name: tickers symbol_unique; Type: CONSTRAINT; Schema: investing; Owner: postgres
--

ALTER TABLE ONLY tickers
    ADD CONSTRAINT symbol_unique UNIQUE (symbol);


--
-- Name: tickers tickers_pkey; Type: CONSTRAINT; Schema: investing; Owner: postgres
--

ALTER TABLE ONLY tickers
    ADD CONSTRAINT tickers_pkey PRIMARY KEY (id);


--
-- Name: tickers stock_exchange_fk; Type: FK CONSTRAINT; Schema: investing; Owner: postgres
--

ALTER TABLE ONLY tickers
    ADD CONSTRAINT stock_exchange_fk FOREIGN KEY (stock_exchange) REFERENCES stock_exchanges(id);


--
-- Name: stock_prices_historical symbol_fk; Type: FK CONSTRAINT; Schema: investing; Owner: postgres
--

ALTER TABLE ONLY stock_prices_historical
    ADD CONSTRAINT symbol_fk FOREIGN KEY (symbol) REFERENCES tickers(symbol);


--
-- Name: stock_prices symbol_fk; Type: FK CONSTRAINT; Schema: investing; Owner: postgres
--

ALTER TABLE ONLY stock_prices
    ADD CONSTRAINT symbol_fk FOREIGN KEY (symbol) REFERENCES tickers(symbol);


--
-- PostgreSQL database dump complete
--

